import streamlit as st
import numpy as np
import joblib
from math import radians, cos, sin, asin, sqrt
from datetime import time

# Load the trained model
model = joblib.load("delivery_eta_model.pkl")

# Haversine function to calculate distance between two lat/lng points
def haversine(lat1, lon1, lat2, lon2):
    R = 6371  # Radius of Earth in km
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    return R * c

# Streamlit UI
st.title("🚚 Delivery ETA Predictor")

pickup_lat = st.number_input("Pickup Latitude", value=12.95)
pickup_lng = st.number_input("Pickup Longitude", value=77.55)
dropoff_lat = st.number_input("Dropoff Latitude", value=13.00)
dropoff_lng = st.number_input("Dropoff Longitude", value=77.60)
pickup_time = st.time_input("Pickup Time", value=time(12, 30))

# Extract hour from time
hour = pickup_time.hour

# Calculate distance using Haversine
distance_km = haversine(pickup_lat, pickup_lng, dropoff_lat, dropoff_lng)

# Prediction button
if st.button("Predict ETA"):
    features = np.array([[pickup_lat, pickup_lng, dropoff_lat, dropoff_lng, distance_km, hour]])
    prediction = model.predict(features)
    st.success(f"Estimated Delivery Time: {round(prediction[0], 2)} minutes")
