import streamlit as st
import pandas as pd
import joblib

st.title("🧾 Invoice Fraud Detection System")

model = joblib.load("fraud_model.pkl")
model_columns = joblib.load("model_columns.pkl")

uploaded_file = st.file_uploader("Upload invoice CSV file", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file)

    df['invoice_date'] = pd.to_datetime(df['invoice_date'])
    df['due_date'] = pd.to_datetime(df['due_date'])
    df['payment_date'] = pd.to_datetime(df['payment_date'])

    df['days_to_due'] = (df['due_date'] - df['invoice_date']).dt.days
    df['payment_delay'] = (df['payment_date'] - df['due_date']).dt.days

    df_orig = df.copy()  # Backup for showing results

    df = df.drop(columns=['invoice_id', 'invoice_date', 'due_date', 'payment_date'], errors='ignore')
    df = pd.get_dummies(df, columns=['vendor_id', 'category'], drop_first=True)

    # Add missing columns from training
    for col in model_columns:
        if col not in df.columns:
            df[col] = 0
    df = df[model_columns]

    # Predict fraud probability
    df_orig["Fraud Probability"] = model.predict_proba(df)[:, 1]
    df_orig["Fraudulent?"] = df_orig["Fraud Probability"].apply(lambda x: "⚠️ Yes" if x > 0.8 else "✅ No")

    st.write("### Results")
    st.dataframe(df_orig.sort_values("Fraud Probability", ascending=False))