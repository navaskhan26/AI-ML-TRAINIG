import streamlit as st
import pandas as pd
from collab_filter import CollaborativeFiltering

# Load example dataset
df = pd.read_csv("movie_ratings.csv")

# Unique movies and users
movie_list = df['movie_id'].unique()
movie_names = {
    101: "Inception",
    102: "Titanic",
    103: "Avengers",
    104: "Matrix",
    105: "Joker",
    106: "Interstellar",
    107: "The Godfather",
    108: "Fight Club"
}


# Simulate adding a new user
new_user_id = df['user_id'].max() + 1

st.title("🎥 Movie Rating Predictor")

st.write("### Rate a few movies")
user_ratings = {}
for movie_id in movie_list:
    name = movie_names.get(movie_id, f"Movie {movie_id}")
    rating = st.slider(f"{name}", 1, 5, 3)
    user_ratings[movie_id] = rating

# Build dataframe with new ratings
user_df = pd.DataFrame([{'user_id': new_user_id, 'movie_id': k, 'rating': v} 
                        for k, v in user_ratings.items()])

# Combine with original dataset
combined_df = pd.concat([df, user_df], ignore_index=True)

# Collaborative filtering prediction
cf_model = CollaborativeFiltering(combined_df)

st.write("### Predicted Ratings for Unseen Movies")

results = []
for movie_id in movie_list:
    if movie_id not in user_ratings:
        pred = cf_model.predict_rating(new_user_id, movie_id)
        results.append((movie_names.get(movie_id, str(movie_id)), pred))

# Show top predictions
result_df = pd.DataFrame(results, columns=["Movie", "Predicted Rating"]).dropna()
result_df = result_df.sort_values("Predicted Rating", ascending=False)
st.dataframe(result_df)
