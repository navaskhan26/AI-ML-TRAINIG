import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

class CollaborativeFiltering:
    def __init__(self, ratings_df):
        self.ratings_df = ratings_df
        self.user_item_matrix = self.ratings_df.pivot_table(index='user_id', columns='movie_id', values='rating')
        self.similarity_matrix = cosine_similarity(self.user_item_matrix.fillna(0))
        self.similarity_df = pd.DataFrame(self.similarity_matrix, 
                                          index=self.user_item_matrix.index, 
                                          columns=self.user_item_matrix.index)

    def predict_rating(self, user_id, movie_id):
        if movie_id not in self.user_item_matrix.columns:
            return np.nan
        if user_id not in self.user_item_matrix.index:
            return np.nan

        sim_users = self.similarity_df[user_id].drop(user_id)
        movie_ratings = self.user_item_matrix[movie_id]

        mask = movie_ratings.notna()
        sim_scores = sim_users[mask]
        ratings = movie_ratings[mask]

        if sim_scores.sum() == 0:
            return np.nan

        weighted_avg = np.dot(sim_scores, ratings) / sim_scores.sum()
        return round(weighted_avg, 2)
