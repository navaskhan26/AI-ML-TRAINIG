import streamlit as st
import pandas as pd
import pickle
from datetime import datetime

with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('product_encoder.pkl', 'rb') as f:
    le_product = pickle.load(f)

with open('location_encoder.pkl', 'rb') as f:
    le_location = pickle.load(f)

st.set_page_config(page_title="Demand Predictor", page_icon="📦")
st.title("📊 Supermarket Product Demand Predictor")

st.markdown("Predict daily product demand based on date, promotion, and store location.")

st.sidebar.header("🛒 Select Inputs")
product = st.sidebar.selectbox("Select Product", le_product.classes_)
location = st.sidebar.selectbox("Select Store Location", le_location.classes_)
date = st.sidebar.date_input("Select Date", datetime(2023, 6, 1))
promotion = st.sidebar.radio("Is a Promotion Running?", [0, 1], format_func=lambda x: "Yes" if x else "No")

dayofweek = date.weekday()
month = date.month
product_enc = le_product.transform([product])[0]
location_enc = le_location.transform([location])[0]

X_input = [[product_enc, location_enc, promotion, dayofweek, month]]
prediction = model.predict(X_input)[0]

st.success(f"📦 **Predicted Demand:** `{int(prediction)} units`")
