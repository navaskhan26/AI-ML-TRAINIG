# Meeting Notes Summarizer Chatbot

A minimal, dependency-light web app that:
- Summarizes meeting transcripts.
- Extracts action items and decisions.
- Guesses attendees, dates, times, and topics.
- Lets you **ask questions** about the transcript in a chat-like UI (simple retrieval-based answers, no external AI).

## Tech
- **Python 3.9+**
- **Flask** (templating + routes)
- Lightweight NLP implemented from scratch (regex + TF-IDF-like math) — no heavy ML libs or API keys required.

## Quick Start

```bash
# 1) Create & activate a virtual environment (recommended)
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

# 2) Install deps
pip install -r requirements.txt

# 3) Run the app
python app.py
# Visit http://localhost:5000
```

## Usage
- Paste your raw meeting transcript or upload a `.txt` file.
- Hit **Summarize** to see:
  - A concise summary (top-scoring sentences).
  - Action Items & Decisions (keyword heuristics).
  - Attendees, dates, times, and topic keywords (lightweight extraction).
- Use the **Ask the Transcript** box to ask follow-up questions. Answers are stitched from the most relevant sentences using cosine similarity over TF‑IDF-style vectors.

> This project intentionally avoids external AI APIs so it runs anywhere. Accuracy depends on transcript quality and may not rival LLMs — but it's fast and private.

## Project Structure
```
meeting-notes-summarizer-chatbot/
├─ app.py
├─ utils.py
├─ requirements.txt
├─ README.md
├─ LICENSE
├─ data/
│  └─ sample_transcript.txt
├─ static/
│  └─ style.css
└─ templates/
   ├─ index.html
   └─ summary.html
```

## Tests
A very small smoke test is included under `tests/` to ensure core functions return something.

## Notes
- If you paste extremely long transcripts (100+ KB), the simple heuristics still work but may take a couple of seconds.
- For production, consider swapping retrieval/QA and summarization with your favorite NLP/LLM, keeping the web UI intact.
