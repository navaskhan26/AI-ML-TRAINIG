from flask import Flask, render_template, request, jsonify
from utils import (
    summarize_by_frequency,
    extract_action_items,
    extract_decisions,
    extract_entities,
    build_retriever,
    answer_question,
    clean_text
)

app = Flask(__name__)

# Global in-memory "session" for demo purposes
STATE = {
    "transcript": "",
    "sentences": [],
    "retriever": None,
    "metadata": {}
}

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/summarize", methods=["POST"])
def summarize():
    text = request.form.get("transcript", "").strip()
    if not text and "file" in request.files:
        file = request.files["file"]
        if file and file.filename:
            text = file.read().decode("utf-8", errors="ignore")

    text = clean_text(text or "")
    if not text:
        return render_template("index.html", error="Please paste a transcript or upload a .txt file.")

    # Build summary + metadata
    summary = summarize_by_frequency(text, max_sentences=8)
    actions = extract_action_items(text)
    decisions = extract_decisions(text)
    entities = extract_entities(text)

    # Build retriever for Q&A
    retriever = build_retriever(text)

    # Save to global state
    STATE["transcript"] = text
    STATE["retriever"] = retriever
    STATE["sentences"] = retriever["sentences"]
    STATE["metadata"] = {
        "attendees": entities.get("attendees", []),
        "dates": entities.get("dates", []),
        "times": entities.get("times", []),
        "topics": entities.get("topics", [])
    }

    return render_template(
        "summary.html",
        summary=summary,
        actions=actions,
        decisions=decisions,
        attendees=STATE["metadata"]["attendees"],
        dates=STATE["metadata"]["dates"],
        times=STATE["metadata"]["times"],
        topics=STATE["metadata"]["topics"],
        transcript_preview="\n".join(STATE["sentences"][:10]) + ("\n..." if len(STATE["sentences"])>10 else "")
    )

@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(force=True)
    question = data.get("question", "").strip()
    if not question:
        return jsonify({"ok": False, "answer": "Please ask a question.", "snippets": []})

    if not STATE["retriever"]:
        return jsonify({"ok": False, "answer": "Please upload/paste a transcript first.", "snippets": []})

    ans, snippets = answer_question(question, STATE["retriever"])
    return jsonify({"ok": True, "answer": ans, "snippets": snippets})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
