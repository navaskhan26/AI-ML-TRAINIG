import utils

def test_summary_not_empty():
    text = "Alice will send the report by Friday. Bob approved the budget."
    s = utils.summarize_by_frequency(text, max_sentences=2)
    assert isinstance(s, str) and len(s) > 0

def test_retriever_answers():
    text = "We decided to ship v1 next week. Carol owns the documentation."
    r = utils.build_retriever(text)
    ans, snips = utils.answer_question("Who owns docs?", r)
    assert isinstance(ans, str)
    assert isinstance(snips, list) and len(snips) > 0
