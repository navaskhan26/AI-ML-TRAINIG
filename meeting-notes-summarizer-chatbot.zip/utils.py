import math
import re
from collections import Counter, defaultdict

STOPWORDS = set("""a about above after again against all am an and any are aren't as at be because been before
being below between both but by can't cannot could couldn't did didn't do does doesn't doing don't down during each
few for from further had hadn't has hasn't have haven't having he he'd he'll he's her here here's hers herself him
himself his how how's i i'd i'll i'm i've if in into is isn't it it's its itself let's me more most mustn't my
myself no nor not of off on once only or other ought our ours  ourselves out over own same shan't she she'd she'll
she's should shouldn't so some such than that that's the their theirs them themselves then there there's these they they'd
they'll they're they've this those through to too under until up very was wasn't we we'd we'll we're we've were weren't
what what's when when's where where's which while who who's whom why why's with won't would wouldn't you you'd you'll you're
you've your yours yourself yourselves""".split())

SENTENCE_SPLIT_RE = re.compile(r'(?<=[.!?])\s+(?=[A-Z0-9])')

def clean_text(text: str) -> str:
    # Normalize weird whitespace, dashes, bullets
    text = text.replace("\r", "\n")
    text = re.sub(r'\t', ' ', text)
    text = re.sub(r'[•·▪►➤\-\u2013\u2014]', ' ', text)
    text = re.sub(r'\s+\n', '\n', text)
    text = re.sub(r'\n{2,}', '\n\n', text)
    return text.strip()

def sentence_tokenize(text: str):
    # Split by punctuation and newlines heuristically
    chunks = []
    for para in text.split("\n"):
        para = para.strip()
        if not para:
            continue
        sents = SENTENCE_SPLIT_RE.split(para)
        for s in sents:
            s = s.strip()
            if s:
                chunks.append(s)
    return chunks

def word_tokenize(text: str):
    return re.findall(r"[A-Za-z0-9']+", text.lower())

def compute_tf(sentences):
    # term frequency per sentence
    tf_list = []
    for s in sentences:
        words = [w for w in word_tokenize(s) if w not in STOPWORDS]
        tf = Counter(words)
        tf_list.append(tf)
    return tf_list

def compute_idf(tf_list):
    # inverse doc frequency over sentences
    df = Counter()
    for tf in tf_list:
        for term in tf.keys():
            df[term] += 1
    N = len(tf_list)
    return {term: math.log((N + 1) / (df[term] + 1)) + 1 for term in df}

def score_sentence(tf, idf):
    score = 0.0
    for term, freq in tf.items():
        score += freq * idf.get(term, 0.0)
    return score

def summarize_by_frequency(text: str, max_sentences: int = 8) -> str:
    sentences = sentence_tokenize(text)
    if not sentences:
        return ""
    tf_list = compute_tf(sentences)
    idf = compute_idf(tf_list)
    scores = [score_sentence(tf, idf) for tf in tf_list]

    # Rank by score but keep original order for ties
    ranked_idx = sorted(range(len(sentences)), key=lambda i: scores[i], reverse=True)[:max_sentences]
    ranked_idx_sorted = sorted(ranked_idx)  # preserve narrative flow

    summary = " ".join(sentences[i] for i in ranked_idx_sorted)
    return summary

def extract_action_items(text: str):
    # Simple heuristic: lines/sentences with "will", "by <date>", imperative verbs, or owner name (e.g., "John to ...")
    sentences = sentence_tokenize(text)
    candidates = []
    for s in sentences:
        s_low = s.lower()
        if any(kw in s_low for kw in [" will ", " to ", " by ", "deadline", "due", "action", "follow up", "follow-up"]):
            if len(s) > 25:
                candidates.append(s)
    # Deduplicate while preserving order
    seen = set()
    actions = []
    for c in candidates:
        c_norm = re.sub(r'\W+', '', c.lower())
        if c_norm not in seen:
            actions.append(c)
            seen.add(c_norm)
    return actions[:20]

def extract_decisions(text: str):
    sentences = sentence_tokenize(text)
    decisions = []
    for s in sentences:
        s_low = s.lower()
        if any(kw in s_low for kw in ["decided", "agree", "approved", "conclude", "consensus", "finalize", "choose", "opt for"]):
            decisions.append(s)
    # Fallback: pick high-scoring sentences mentioning "will"
    if not decisions:
        for s in sentences:
            if " will " in s.lower():
                decisions.append(s)
    return decisions[:15]

def extract_entities(text: str):
    # Heuristic extraction of people (capitalized names), dates, times, topics (hashtags or key nouns)
    sentences = sentence_tokenize(text)
    attendees = []
    for s in sentences:
        # Look for patterns like "Attendees:", "Present:", or "With <Names>"
        if re.search(r'(?i)(attendees|present|participants)\s*[:\-]', s):
            names = re.findall(r'([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)', s)
            attendees.extend(names)

    # Also infer recurring capitalized tokens that look like names
    cap_words = re.findall(r'\b([A-Z][a-z]+(?:\s[A-Z][a-z]+){0,2})\b', text)
    # Filter common non-names
    blocklist = set(['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday',
                     'January','February','March','April','May','June','July','August','September','October','November','December',
                     'AM','PM','GMT','IST','CEO','CTO','CFO','PMO','OKR','FYI','Q1','Q2','Q3','Q4','Roadmap','Minutes'])
    for w in cap_words:
        if w not in blocklist and len(w.split())<=3 and w not in attendees:
            # a naive heuristic: if it appears more than once, likely a person
            if text.count(w) > 1:
                attendees.append(w)

    attendees = list(dict.fromkeys(attendees))[:15]

    # Dates & times
    dates = re.findall(r'\b(?:\d{1,2}[/-])?\d{1,2}[/-]\d{2,4}|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\s+\d{1,2}(?:,\s*\d{4})?', text, flags=re.I)
    times = re.findall(r'\b\d{1,2}:\d{2}\s*(?:AM|PM|am|pm)?|\b\d{1,2}\s*(?:AM|PM|am|pm)\b', text)

    # Topics: most frequent non-stopword tokens
    words = [w for w in word_tokenize(text) if w not in STOPWORDS and len(w)>2]
    top = [w for w,_ in Counter(words).most_common(10)]
    return {"attendees": attendees, "dates": dates[:10], "times": times[:10], "topics": top}

def build_retriever(text: str, window: int = 2):
    # Split into sentences, build tf-idf-like vectors
    sentences = sentence_tokenize(text)
    tf_list = compute_tf(sentences)
    idf = compute_idf(tf_list)

    # Build normalized vectors
    vectors = []
    vocab = sorted({t for tf in tf_list for t in tf})
    for tf in tf_list:
        vec = [tf.get(t, 0) * idf.get(t, 0.0) for t in vocab]
        # L2 normalize
        norm = math.sqrt(sum(v*v for v in vec)) or 1.0
        vec = [v / norm for v in vec]
        vectors.append(vec)
    return {"sentences": sentences, "vocab": vocab, "idf": idf, "vectors": vectors}

def cosine(a, b):
    return sum(x*y for x,y in zip(a,b))

def vectorize_query(q, vocab, idf):
    tf = Counter([w for w in word_tokenize(q) if w not in STOPWORDS])
    vec = [tf.get(t, 0) * idf.get(t, 0.0) for t in vocab]
    norm = math.sqrt(sum(v*v for v in vec)) or 1.0
    return [v / norm for v in vec]

def answer_question(question: str, retriever, k: int = 4):
    qvec = vectorize_query(question, retriever["vocab"], retriever["idf"])
    scores = [(i, cosine(qvec, v)) for i, v in enumerate(retriever["vectors"])]
    scores.sort(key=lambda x: x[1], reverse=True)
    top_idx = [i for i,_ in scores[:k]]
    sentences = retriever["sentences"]
    snippets = [sentences[i] for i in top_idx]
    # Naive "answer": join top snippets; if nothing matches, say so
    answer = " ".join(snippets) if snippets and sum(s for _,s in scores[:k])>0.0001 else "I couldn't find that in the transcript."
    return answer, snippets
